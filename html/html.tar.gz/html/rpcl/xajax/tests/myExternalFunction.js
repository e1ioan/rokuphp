function myFunction()
{
	alert('Congratulations!\n  You have successfully included the\n myExternalFunction.js without reloading the page.');
}