// This file is intentionally empty, you should deploy to mobile to get the right cordova file

if(window.console && window.console.log)
    console.log("the included cordova file is intentionally empty, you should deploy to mobile to run the mobile hardware components");
