<?php
<object class="dm" name="dm" baseclass="DataModule">
  <property name="Animations">a:0:{}</property>
  <property name="Height">370</property>
  <property name="Name">dm</property>
  <property name="Width">597</property>
  <object class="MobileTheme" name="MobileTheme1" >
        <property name="Left">128</property>
        <property name="Top">64</property>
    <property name="ColorVariation">cvHigh</property>
    <property name="Name">MobileTheme1</property>
  </object>
</object>
?>
